-- AlterTable
ALTER TABLE `users` MODIFY `phoneNumber` VARCHAR(191) NULL;
