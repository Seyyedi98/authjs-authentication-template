import ErrorCard from "@/app/_components/ui/cards/error-card";
import React from "react";

const AuthErrorPage = () => {
  return <ErrorCard />;
};

export default AuthErrorPage;
