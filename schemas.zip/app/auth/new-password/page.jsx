import { CredentialsNewPasswordForm } from "@/app/_components/auth/credentials-new-password-form";
import React from "react";

const NewPasswordPage = () => {
  return <CredentialsNewPasswordForm />;
};

export default NewPasswordPage;
