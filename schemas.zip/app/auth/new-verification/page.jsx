import { NewVerificationForm } from "@/app/_components/auth/new-verification-form";
import React from "react";

const NewVarificationPage = () => {
  return <NewVerificationForm />;
};

export default NewVarificationPage;
