import { CredentialsResetForm } from "@/app/_components/auth/credentials-reset-form";
import React from "react";

const ResetPage = () => {
  return <CredentialsResetForm />;
};

export default ResetPage;
